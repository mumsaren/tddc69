package se.liu.ida.denlj069.tddc69.project.Player;

/**
 * Created with IntelliJ IDEA.
 * User: Mumsaren
 * Date: 2013-10-10
 * Time: 21:41
 * To change this template use File | Settings | File Templates.
 */
public interface PlayerListener {

    public void playerChanged();

}
